// src/server.js
const http = require("http");
const app = require("./index");
const { Server } = require("socket.io");

const PORT = process.env.PORT || 3000;

// Create HTTP server
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*", // Adjust this to your frontend URL in production
    methods: ["GET", "POST"],
  },
});

io.on("connection", (socket) => {
  console.log(`User connected: ${socket.id}`);

  // When a user joins a specific chat room (e.g., for a match)
  socket.on("joinChat", async (data) => {
    const { userId, matchId } = data; // Assuming userId is passed after authentication on client
    // In a real app, you'd verify userId with a token here.
    // For now, let's assume `userId` is valid.

    // Check if the user is part of this match and it's approved
    try {
      const match = await prisma.match.findUnique({
        where: { id: matchId },
        select: {
          user1Id: true,
          user2Id: true,
          approvedByUser1: true,
          approvedByUser2: true,
        },
      });

      if (!match || (match.user1Id !== userId && match.user2Id !== userId)) {
        console.warn(
          `User ${userId} attempted to join unauthorized match ${matchId}`
        );
        socket.emit("chatError", "Unauthorized to join this chat.");
        return;
      }

      if (!match.approvedByUser1 || !match.approvedByUser2) {
        console.warn(
          `User ${userId} attempted to join unapproved match ${matchId}`
        );
        socket.emit(
          "chatError",
          "Chat is not available until match is mutually approved."
        );
        return;
      }

      socket.join(matchId); // Join a room named after the matchId
      console.log(`User ${userId} joined chat room: ${matchId}`);
      socket.emit(
        "chatJoined",
        `Successfully joined chat for match ${matchId}`
      );
    } catch (error) {
      console.error(
        `Error joining chat for user ${userId} and match ${matchId}:`,
        error
      );
      socket.emit("chatError", "Failed to join chat.");
    }
  });

  // When a user sends a message
  socket.on("sendMessage", async (data) => {
    const { matchId, senderId, receiverId, message } = data; // senderId should ideally come from auth on server side

    if (!matchId || !senderId || !receiverId || !message) {
      socket.emit("chatError", "Invalid message data.");
      return;
    }

    try {
      // Verify match status again (important for security)
      const match = await prisma.match.findUnique({
        where: { id: matchId },
        select: {
          user1Id: true,
          user2Id: true,
          approvedByUser1: true,
          approvedByUser2: true,
        },
      });

      if (
        !match ||
        !match.approvedByUser1 ||
        !match.approvedByUser2 ||
        !(
          (match.user1Id === senderId && match.user2Id === receiverId) ||
          (match.user1Id === receiverId && match.user2Id === senderId)
        )
      ) {
        socket.emit(
          "chatError",
          "Cannot send message: Invalid or unapproved match."
        );
        return;
      }

      // Save message to database
      const newChatMessage = await prisma.chatMessage.create({
        data: {
          senderId: senderId,
          receiverId: receiverId,
          message: message,
        },
      });

      // Emit message to all clients in the match room
      io.to(matchId).emit("receiveMessage", {
        id: newChatMessage.id,
        senderId: newChatMessage.senderId,
        receiverId: newChatMessage.receiverId,
        message: newChatMessage.message,
        createdAt: newChatMessage.createdAt,
        // You might want to include sender's name/avatar here by fetching it
        // For simplicity, client can look up sender info based on ID
      });
    } catch (error) {
      console.error("Error saving or sending message:", error);
      socket.emit("chatError", "Failed to send message.");
    }
  });

  socket.on("disconnect", () => {
    console.log(`User disconnected: ${socket.id}`);
  });
});

// Start listening for HTTP requests

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log("API Endpoints:");
  console.log(`  http://localhost:${PORT}/api/users/recommendations`);
  console.log(`  http://localhost:${PORT}/api/likes`);
  console.log(`  http://localhost:${PORT}/api/matches`);
  console.log(`  http://localhost:${PORT}/api/matches/{matchId}/approve`);
  console.log(`  http://localhost:${PORT}/api/chats/{matchId}/messages`);
  console.log(`  http://localhost:${PORT}/api/tasks`);
  console.log(`  http://localhost:${PORT}/api/tasks?date=YYYY-MM-DD`);
  console.log(`  http://localhost:${PORT}/api/tasks/{taskId}/status`);
});

// Graceful shutdown
process.on("beforeExit", async () => {
  await prisma.$disconnect();
});
