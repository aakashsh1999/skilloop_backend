// src/controllers/chatController.js
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// This controller handles fetching historical messages.
// Real-time messaging will be handled by Socket.IO directly in server.js or a separate socket handler.

exports.getChatMessages = async (req, res) => {
  const userId = req.user.id; // Authenticated user
  const { matchId } = req.params;

  try {
    const match = await prisma.match.findUnique({
      where: { id: matchId },
      select: {
        user1Id: true,
        user2Id: true,
        approvedByUser1: true,
        approvedByUser2: true,
      },
    });

    if (!match) {
      return res.status(404).json({ message: "Match not found." });
    }

    // Verify that the requesting user is part of the match
    if (match.user1Id !== userId && match.user2Id !== userId) {
      return res
        .status(403)
        .json({ message: "You are not authorized to view this chat." });
    }

    // Verify that the match is fully approved before allowing chat history
    if (!match.approvedByUser1 || !match.approvedByUser2) {
      return res
        .status(403)
        .json({
          message: "Chat is not available until match is mutually approved.",
        });
    }

    // Fetch messages between these two users (order-agnostic)
    const messages = await prisma.chatMessage.findMany({
      where: {
        OR: [
          { senderId: match.user1Id, receiverId: match.user2Id },
          { senderId: match.user2Id, receiverId: match.user1Id },
        ],
      },
      orderBy: { createdAt: "asc" }, // Order by time
      include: {
        sender: { select: { id: true, name: true, avatar: true } },
      },
    });

    res.json(messages);
  } catch (error) {
    console.error("Error fetching chat messages:", error);
    res.status(500).json({ message: "Internal server error." });
  }
};
