// src/routes/userRoutes.js
const express = require("express");
const router = express.Router();
const userController = require("../controller/userControllers.js");

router.get("/", userController.getUserDetails); // Example: /api/users?mobile_number=... or ?user_id=...
router.get("/nearby", userController.getNearbyUsers); // Example: /api/users/nearby?latitude=...&longitude=...&radius_km=...
// router.get("/:id", userController.getUserProfile);
router.get("/recommendations/:userId", userController.getRecommendedUsers);

module.exports = router;
