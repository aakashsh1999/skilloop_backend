// src/routes/matchRoutes.js
const express = require("express");
const router = express.Router();
const matchController = require("../controller/matchControllers.js");

// Get all matches for the current user
router.get("/", matchController.getMatches);

// Approve a specific match
router.patch("/:matchId/approve", matchController.approveMatch);
router.get("/chats", matchController.getChatListForUser); // This is the new route

module.exports = router;
