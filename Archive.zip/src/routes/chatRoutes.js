// src/routes/chatRoutes.js
const express = require("express");
const router = express.Router();
const chatController = require("../controller/chatController.js");

// Get chat messages for a specific match
router.get("/:matchId/messages", chatController.getChatMessages);

module.exports = router;
