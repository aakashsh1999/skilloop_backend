// src/routes/likeRoutes.js
const express = require("express");
const router = express.Router();
const likeController = require("../controller/likeMatchController.js");

// Like a user
router.post("/", likeController.likeUser);

// Unlike a user (optional)
router.delete("/", likeController.unlikeUser);

module.exports = router;
